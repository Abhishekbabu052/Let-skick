<?php
session_start();
$conn = new mysqli("localhost", "root", "", "medicine_store");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch feedback with user names
$result = $conn->query("
    SELECT feedback.*, users.username 
    FROM feedback 
    LEFT JOIN users ON feedback.user_id = users.id 
    ORDER BY feedback.id DESC
");
?>

<!DOCTYPE html>
<html>
<head><title>Feedback List</title></head>
<body>
<h2>Submitted Feedback</h2>

<?php
if ($result->num_rows == 0) {
    echo "<p>No feedback found.</p>";
} else {
    while ($row = $result->fetch_assoc()) {
        echo "<div style='border:1px solid #ccc; padding:10px; margin-bottom:15px;'>";
        echo "<strong>ID:</strong> " . $row['id'] . "<br>";
        echo "<strong>User:</strong> " . htmlspecialchars($row['username'] ?? 'Unknown') . "<br>";
        echo "<strong>Subject:</strong> " . htmlspecialchars($row['subject']) . "<br>";
        echo "<strong>Message:</strong><br>" . nl2br(htmlspecialchars($row['message'])) . "<br>";
        echo "<strong>Status:</strong> " . htmlspecialchars($row['status']) . "<br>";
        echo "<strong>Submitted At:</strong> " . $row['submitted_at'] . "<br>";

        if (!empty($row['image_path'])) {
            echo "<strong>Image:</strong><br><img src='" . $row['image_path'] . "' width='200'><br>";
        } else {
            echo "<strong>Image:</strong> None<br>";
        }

        echo "</div>";
    }
}
?>
</body>
</html>

