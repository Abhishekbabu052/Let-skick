<?php
session_start();
$conn = new mysqli("localhost", "root", "", "medicine_store");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_GET["id"])) {
    die("Medicine ID missing.");
}

$medicine_id = intval($_GET["id"]);
$medicine = $conn->query("SELECT * FROM medicine WHERE id=$medicine_id")->fetch_assoc();
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $address = $_POST["address"];
    $phone = $_POST["phone"];
    $pincode = $_POST["pincode"];
    $price = $_POST["price"];
    $user_id = isset($_SESSION["user_id"]) ? intval($_SESSION["user_id"]) : 0;

    $sql = "INSERT INTO orders (user_id, name, price, address, phone, pincode)
            VALUES ($user_id, '$name', '$price', '$address', '$phone', '$pincode')";

    if ($conn->query($sql) === TRUE) {
        $message = "✅ Order placed successfully.";
    } else {
        $message = "❌ Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Order Medicine</title>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: #f5fdfd;
      margin: 0;
      padding: 20px;
      color: #333;
    }

    h2, h3, p {
      margin: 0 0 10px 0;
      text-align: center;
    }

    .medicine-name {
      font-size: 24px;
      font-weight: 700;
      color: #004d40;
      margin-bottom: 5px;
    }

    .medicine-description {
      font-size: 16px;
      color: #555;
      font-style: italic;
      margin-bottom: 8px;
    }

    .medicine-price {
      font-size: 20px;
      font-weight: 600;
      color: #009688;
      margin-bottom: 15px;
    }

    img {
      display: block;
      margin: 15px auto;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }

    form {
      max-width: 500px;
      margin: 20px auto;
      padding: 20px;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 6px 18px rgba(0,0,0,0.1);
    }

    label {
      font-weight: 600;
      display: block;
      margin: 10px 0 5px;
    }

    input[type="text"], textarea {
      width: 100%;
      padding: 10px;
      border: 2px solid #00bfa5;
      border-radius: 10px;
      font-size: 14px;
      outline: none;
      transition: 0.3s;
    }

    input[type="text"]:focus, textarea:focus {
      border-color: #00796b;
      box-shadow: 0 0 6px rgba(0,191,165,0.3);
    }

    textarea {
      resize: none;
      height: 80px;
    }

    input[type="submit"] {
      width: 100%;
      padding: 12px;
      background: linear-gradient(135deg, #00bfa5, #00695c);
      color: #fff;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      margin-top: 15px;
      transition: 0.3s ease;
    }

    input[type="submit"]:hover {
      transform: scale(1.03);
      box-shadow: 0 6px 20px rgba(0,191,165,0.3);
    }

    .message {
      text-align: center;
      font-weight: 600;
      margin: 12px 0;
    }
    .message:contains("✅") { color: green; }
    .message:contains("❌") { color: red; }
  </style>
</head>
<body>

<h2 class="medicine-name">Order: <?php echo $medicine["name"]; ?></h2>
<p class="medicine-description"><?php echo $medicine["description"]; ?></p>
<p class="medicine-price">Price: ₹<?php echo $medicine["price"]; ?></p>
<img src="<?php echo $medicine["image"]; ?>" width="120"><br><br>

<?php echo $message ? "<p class='message'>$message</p>" : ""; ?>

<form method="POST">
    <input type="hidden" name="price" value="<?php echo $medicine["price"]; ?>">
    <label>Your Name:</label><br>
    <input type="text" name="name" required><br>
    <label>Address:</label><br>
    <textarea name="address" required></textarea><br>
    <label>Phone:</label><br>
    <input type="text" name="phone" required><br>
    <label>Pincode:</label><br>
    <input type="text" name="pincode" required><br><br>
    <input type="submit" value="Place Order">
</form>

</body>
</html>

